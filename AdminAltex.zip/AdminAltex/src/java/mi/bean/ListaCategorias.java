/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.bean;

import java.util.List;
import mi.obj.categorias;

/**
 *
 * @author blunkers
 */
public class ListaCategorias {
   private List<categorias> listacategorias;

    public List<categorias> getListacategorias() {
        return listacategorias;
    }

    public void setListacategorias(List<categorias> listacategorias) {
        this.listacategorias = listacategorias;
    }
   
   
}
