/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

  $(document).ready(function(){
      
      $('select').formSelect();
      
      $('.collapsible').collapsible({
            menuWidth: 300,
            accordion : true
        });
        
      $('#example').DataTable( {
          "bLengthChange": false,
          "language": {
                    "lengthMenu": "Mostrar _MENU_",
                    "zeroRecords": "Nothing found - sorry",
                    "info": "Página _PAGE_ de _PAGES_ ",
                            //Registros _PAGE_ de Páginas",
                    "infoEmpty": "No records available",
                    "infoFiltered": "(Filtrados from _MAX_ total de registros)"
                }
           });
       });
         
         $(window).load(function(){

 $(function() {
  $('#file-input').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida').attr("src",result);
     }
    });
  });
  
    function  getContextPath() {
           return window.location.pathname.substring(0,window.location.pathname.indexOf("/",2));
    }
    
    $(function(){
        $("#formuploadajax").on("submit", function(e){
            e.preventDefault();
            var f = $(this);
            var formData = new FormData(document.getElementById("formuploadajax"));
            formData.append("dato", "valor");
            $.ajax({
                url: getContextPath()+"/categoriasAdd",
                type: "post",
                dataType: "html",
                data: formData,
                cache: false,
                contentType: false,
	        processData: false,
                success: function(res){
                    if(res==="exito"){
                        if (confirm("La categoría se agregó correctamente. "
                                + "¿Desea seguir agregando categorías?")) {
                            $('#formuploadajax')[0].reset();
                            //location.href = "checkout.html";
                        }else{location.href = "checkout.html";}
                    }else{
                        alert("Lo sentimos, ocurrió un error.");
                        //$('#formuploadajax')[0].reset();
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
                    
            });
        });
    });

