/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.servlet;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import mi.bean.ListaCategorias;
import mi.obj.categorias;

/**
 *
 * @author blunkers
 */
@WebServlet(name = "eligeCategorias", urlPatterns = {"/eligeCategorias"})
public class eligeCategorias extends HttpServlet {
    

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    
        response.setContentType("application/json");
        Context envContext = null;
        Connection con=null;
        
        
        PrintWriter out = response.getWriter();
        
        try {  
            ListaCategorias listacategorias=new ListaCategorias();
            List<categorias> categorias=new ArrayList<>();
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            con = ds.getConnection();
            
            String sql = "select idCat,nombre from categorias where estatus='Activo'";
            PreparedStatement statement = con.prepareStatement(sql);

            ResultSet result = statement.executeQuery();
            while(result.next()){
                categorias cat=new categorias();
                cat.setIdCat(result.getInt(1));
                cat.setNombre(result.getString(2));
                categorias.add(cat);
            }
            
            System.out.println("--categorias"+categorias.size());
            if(categorias != null && categorias.size() > 0){
                listacategorias.setListacategorias(categorias);
                
                Gson gson = new Gson();
                String json = gson.toJson(listacategorias);
                out.print(json);
            }
            
        }catch(Exception ex){
        ex.printStackTrace();
        out.print("error");
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(categoriasAdd.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    
}
