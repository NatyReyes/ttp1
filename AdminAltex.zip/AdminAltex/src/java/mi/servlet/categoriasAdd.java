/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.servlet;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javazoom.upload.MultipartFormDataRequest;
import javazoom.upload.UploadFile;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileItemFactory;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author blunkers
 */
public class categoriasAdd extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Context envContext = null;
        Connection con=null;
        try {
            
            
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            //DataSource ds = (DataSource)envContext.lookup("java:/comp/env/jdbc/testDB");
            con = ds.getConnection();
            
            PreparedStatement preparedStatement = null;
            String insertTableSQL = "INSERT INTO Categorias"
				+ "(nombre, estatus, imagen,idCat) VALUES"
				+ "(?,?,?,NULL)";
            
            preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setString(1, "demo27");
            preparedStatement.setString(2, "Activo");
            preparedStatement.setString(3, "imagen");

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

            System.out.println("Record is inserted into DBUSER table!");

        }catch(Exception ex){
            ex.printStackTrace();
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(categoriasAdd.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Context envContext = null;
        Connection con=null;
        try {
             MultipartFormDataRequest mrequest=new MultipartFormDataRequest(request);
             mrequest.getParameter("categoria");
             System.out.println("...."+mrequest.getParameter("categoria"));
//             boolean isMultipart = ServletFileUpload.isMultipartContent(request);
//             if (isMultipart) {
//                 FileItemFactory factory = new DiskFileItemFactory();
//                 ServletFileUpload upload = new ServletFileUpload(factory);
//                List items = null;
//                items = upload.parseRequest((RequestContext) request);
//                Iterator itr = items.iterator();
//                while (itr.hasNext()) 
//                {
//                FileItem item = (FileItem) itr.next();
//                try {
//                String itemName = item.getName();
//                    System.out.println("-----"+itemName);
//                File savedFile = new File("/Users/blunkers/Desktop/"+itemName);
//                item.write(savedFile);
//                } catch (Exception e) {
//                e.printStackTrace();
//                }
//                }
//             }

if (MultipartFormDataRequest.isMultipartFormData(request)) {
 //MultipartFormDataRequest mrequest = new MultipartFormDataRequest(request);
 String todo = null;
 if (mrequest != null) {
  todo = mrequest.getParameter("file-input");
 }
 if ((todo != null)) {
  Hashtable files = mrequest.getFiles();
  if ((files != null) && (!files.isEmpty())) {
   java.text.SimpleDateFormat formato = new java.text.SimpleDateFormat("yyMMddHHmmss");
   String archivo = ((UploadFile) mrequest.getFiles().get("file-input")).getFileName();
   int posicionPunto = archivo.indexOf(".");
   String nombreImagen = archivo.substring(0, posicionPunto);
   String extension = archivo.substring(posicionPunto);
   nombreImagen = nombreImagen + formato.format(new java.util.Date());
   nombreImagen = nombreImagen + extension;
   ((UploadFile) mrequest.getFiles().get("file-input")).setFileName(nombreImagen);
   UploadFile file = (UploadFile) files.get("file-input");
   if (file != null) {
       System.out.println("El archivo: " + file.getFileName() + " se subio correctamente");
   }
  // upBean.store(mrequest, "uploadfile");
  } else {
    System.out.println("Archivos no subidos");
  }
 } else {
   System.out.println("<BR> todo=" + todo);
 }
}

            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            //DataSource ds = (DataSource)envContext.lookup("java:/comp/env/jdbc/testDB");
            con = ds.getConnection();
            
            PreparedStatement preparedStatement = null;
            String insertTableSQL = "INSERT INTO Categorias"
				+ "(nombre, estatus, imagen,idCat) VALUES"
				+ "(?,?,?,NULL)";
            
            preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setString(1, "demo27");
            preparedStatement.setString(2, "Activo");
            preparedStatement.setString(3, "imagen");

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

            System.out.println("Record is inserted into DBUSER table!");

        }catch(Exception ex){
            ex.printStackTrace();
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(categoriasAdd.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
                         
       
    }

    
}
