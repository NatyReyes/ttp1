/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/* global sqlitePlugin, Connection */

var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },

    receivedEvent: function() {
        $("#btnLogin").on("click",this.login);
    },
    
    
    login:function(){
        var user= $("#username").val();
        var pass= $("#pass").val();
        alert(user+"--"+pass);
        if(navigator.connection.type === Connection.NONE){
            var mydb = window.openDatabase('Prueba', '1.0', 'My test database', 1024 * 1024, function(mydb) {});
            if (mydb){ 
                alert("Buscar usuario");
            }else{
              alert("No hay conexión");
            }
         }else{
             //alert('Connection type: ' + navigator.connection.type);
             var mydb = window.openDatabase('altexdb', '1.0', 'proyecto', 1024 * 1024, function(mydb) {});
            if (mydb){ 
                 mydb.transaction(function (t) {
                    t.executeSql("SELECT * FROM usuarios", [user,pass], function (res) {
                       if (res.rows.length>0) {
                           alert("existe");
                           window.open("home.html");
                       }
                       
                   }, function(t, error) {
                    //alert('SELECT error: ' + error.message);
                    alert("Favor de configurar la aplicación.");
                  }
                   );
                  });

       
            }else{
              alert("No hay conexión");
            }
        }
         
       
        //checkConnection();
        //location.href = "home.html";
       /* var mydb = window.openDatabase('Prueba', '1.0', 'My test database', 1024 * 1024, function(mydb) {});
        mydb.transaction(function (t) {
          alert("CONSULTA");
         t.executeSql("SELECT * FROM Prueba", [], consultaPrueba);
        });

        function consultaPrueba(transaction,results) {
            //var divPrueba= document.getElementById("divPrueba");
            var texto="";
            var len = results.rows.length;
            alert("DEMO table: " + len + " rows found.");
            for (var i=0; i<len; i++) {
                var row = results.rows.item(i);
                texto+=row.fechaPrueba+" "+row.itemPrueba;
                //divPrueba.insertAdjacentHTML("beforeend",row.fechaPrueba +'<br>'+row.itemPrueba +'<br>'+row.mensajePrueba );
            }
            alert(texto);
        }
        
        */
       
        //app.receivedEvent('deviceready');
    }
  
   

};

app.initialize();
    