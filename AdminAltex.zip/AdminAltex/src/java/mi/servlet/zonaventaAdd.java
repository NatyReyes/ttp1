/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author blunkers
 */
@WebServlet(name = "zonaventaAdd", urlPatterns = {"/zonaventaAdd"})

public class zonaventaAdd extends HttpServlet {
     
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Context envContext = null;
        Connection con=null;
        String nombre="",codigo="",observaciones="";
        PrintWriter out = response.getWriter();
        
        try {  
            codigo = request.getParameter("codigo");
            nombre = request.getParameter("desc");
            observaciones = request.getParameter("obs");
            System.out.println("--"+nombre);
            System.out.println("**"+codigo);
        
            if(!codigo.equals("") && !nombre.equals("")){
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            con = ds.getConnection();
            
                
            String insertTableSQL = "INSERT INTO zonaventa"
				+ "(codigo, estatus,descripcion,observaciones,idZv)"
                                + " VALUES"
				+ "(?,?,?,?,NULL)";
            
            PreparedStatement preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setString(1, codigo);
            preparedStatement.setString(2, "Activo");
            preparedStatement.setString(3, nombre);
            preparedStatement.setString(4, observaciones);

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

            System.out.println("se insertó zona de venta!");
            out.print("exito");
         }else{
             System.out.println("datos no validos");
             out.print("error");
         }

       }catch(Exception ex){
            ex.printStackTrace();
            out.print("error");
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(categoriasAdd.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
                         
       
    }

    
}
