/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author blunkers
 */
@WebServlet(name = "asignacategorias", urlPatterns = {"/asignacategorias"})
public class asignacategorias extends HttpServlet {

  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Context envContext = null;
        Connection con=null;
        PrintWriter out = response.getWriter();
        try{
            
            String nc=request.getParameter("presentacion");
            String []destino=request.getParameterValues("destino[]");
            
            System.out.println("---"+nc);
            
                
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            //DataSource ds = (DataSource)envContext.lookup("java:/comp/env/jdbc/testDB");
            con = ds.getConnection();
            
            PreparedStatement preparedStatement = null;
            String insertTableSQL = "INSERT INTO presentacionescat"
				+ "(idPre, idCat,idPc) VALUES"
				+ "(?,?,NULL)";
            for (int i = 0; i < destino.length; i++) {
               System.out.println("---"+destino[i]);
            preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setInt(1, Integer.parseInt(nc));
            preparedStatement.setInt(2, Integer.parseInt(destino[i]));
           
            preparedStatement.executeUpdate();
            }

            System.out.println("Exito se inserto usuario");
            out.print("exito");
        }catch(Exception ex){
            ex.printStackTrace();
            out.print("fail");
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                }catch(Exception ex){
                    
                }
            }
     }
      out.close();
    }

}
