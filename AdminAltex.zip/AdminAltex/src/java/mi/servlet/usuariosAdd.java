/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author blunkers
 */
@WebServlet(name = "usuariosAdd", urlPatterns = {"/usuariosAdd"})
public class usuariosAdd extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Context envContext = null;
        Connection con=null;
        PrintWriter out = response.getWriter();
        try{
            
            String nc=request.getParameter("nc");
            String usuario=request.getParameter("usuario");
            String estatus="Activo";//request.getParameter("codigo");
            String correo=request.getParameter("correo");
            String pass=request.getParameter("pass");
            int idgpo=1;
            String grupo=request.getParameter("grupo");
            if(request.getParameter("grupo")!=null && !grupo.equals("")){idgpo=Integer.parseInt(request.getParameter("grupo"));}
            
            //stream expresiones lamda
            //hilos executer services mejora en 8 
            //asincrona
            
            
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            //DataSource ds = (DataSource)envContext.lookup("java:/comp/env/jdbc/testDB");
            con = ds.getConnection();
            
            PreparedStatement preparedStatement = null;
            String insertTableSQL = "INSERT INTO usuarios"
				+ "(nombre_usuario, nombre_completo,estatus,email, contrasenia,"
                                + "idGpo,idUsr) VALUES"
				+ "(?,?,?,?,?,?,NULL)";
            
            preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setString(1, usuario);
            preparedStatement.setString(2, nc);
            preparedStatement.setString(3, estatus);
            
            preparedStatement.setString(4, correo);
            preparedStatement.setString(5, pass);
            preparedStatement.setInt(6, idgpo);

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

            System.out.println("Exito se inserto usuario");
            out.print("exito");
        }catch(Exception ex){
            ex.printStackTrace();
            out.print("fail");
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                }catch(Exception ex){
                    
                }
            }
     }
      out.close();
    }

    
}
