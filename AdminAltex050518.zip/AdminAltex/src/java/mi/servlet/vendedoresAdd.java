/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author blunkers
 */
public class vendedoresAdd extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        Context envContext = null;
        Connection con=null;
        try{
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            //DataSource ds = (DataSource)envContext.lookup("java:/comp/env/jdbc/testDB");
            con = ds.getConnection();
            
            PreparedStatement preparedStatement = null;
            String insertTableSQL = "INSERT INTO Categorias"
				+ "(nombre, estatus, imagen,idCat) VALUES"
				+ "(?,?,?,NULL)";
            
            preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setString(1, "demo27");
            preparedStatement.setString(2, "Activo");
            preparedStatement.setString(3, "imagen");

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

            System.out.println("Record is inserted into DBUSER table!");

        }catch(Exception ex){
            ex.printStackTrace();
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                }catch(Exception ex){
                    
                }
            }
     }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Context envContext = null;
        Connection con=null;
        try{
            
            String codigo=request.getParameter("codigo");
            String nombre=request.getParameter("nomvendedor");
            String estatus="Activo";//request.getParameter("codigo");
            String correo=request.getParameter("correo");
            String obs=request.getParameter("obs");
            int idzona=1;
            System.out.println("nombre"+nombre);
            System.out.println("----"+codigo);
            System.out.println("...."+request.getParameter("zona"));
            String zona=request.getParameter("zona");
            if(request.getParameter("zona")!=null && !zona.equals("")){idzona=Integer.parseInt(request.getParameter("zona"));}
            
            //stream expresiones lamda
            //hilos executer services mejora en 8 
            //asincrona
            
            
            envContext = new InitialContext();
            Context initContext  = (Context)envContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)initContext.lookup("jdbc/altex");
            //DataSource ds = (DataSource)envContext.lookup("java:/comp/env/jdbc/testDB");
            con = ds.getConnection();
            
            PreparedStatement preparedStatement = null;
            String insertTableSQL = "INSERT INTO vendedores"
				+ "(codigo, nombre,estatus,email, observaciones,idZv,idVend) VALUES"
				+ "(?,?,?,?,?,?,NULL)";
            
            preparedStatement = con.prepareStatement(insertTableSQL);
            
            preparedStatement.setString(1, codigo);
            preparedStatement.setString(2, nombre);
            preparedStatement.setString(3, estatus);
            
            preparedStatement.setString(4, correo);
            preparedStatement.setString(5, obs);
            preparedStatement.setInt(6, idzona);

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

            System.out.println("Exito se inserto vendedor");

        }catch(Exception ex){
            ex.printStackTrace();
        
        }finally{
            if (con != null) {
                try {
                    con.close();
                }catch(Exception ex){
                    
                }
            }
     }
        
    }

    
}
