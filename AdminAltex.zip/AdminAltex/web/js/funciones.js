/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


 
if($('#tusuarios').is(":visible")){
    //alert("activa tabla user");
    $('#tusuarios').DataTable( {
          "bLengthChange": false,
          "language": {
                    "lengthMenu": "Mostrar _MENU_",
                    "zeroRecords": "Nothing found - sorry",
                    "info": "Página _PAGE_ de _PAGES_ ",
                            //Registros _PAGE_ de Páginas",
                    "infoEmpty": "No records available",
                    "infoFiltered": "(Filtrados from _MAX_ total de registros)"
                }
           });
}
if($('#tcategorias').is(":visible")){
    //alert("activa tabla user");
    $('#tcategorias').DataTable( {
          "bLengthChange": false,
          "language": {
                    "lengthMenu": "Mostrar _MENU_",
                    "zeroRecords": "Nothing found - sorry",
                    "info": "Página _PAGE_ de _PAGES_ ",
                            //Registros _PAGE_ de Páginas",
                    "infoEmpty": "No records available",
                    "infoFiltered": "(Filtrados from _MAX_ total de registros)"
                }
           });
}

if($('#tvendedores').is(":visible")){
    //alert("activa tabla user");
    $('#tvendedores').DataTable( {
          "bLengthChange": false,
          "language": {
                    "lengthMenu": "Mostrar _MENU_",
                    "zeroRecords": "Nothing found - sorry",
                    "info": "Página _PAGE_ de _PAGES_ ",
                            //Registros _PAGE_ de Páginas",
                    "infoEmpty": "No records available",
                    "infoFiltered": "(Filtrados from _MAX_ total de registros)"
                }
           });
}

if($('#tzonas').is(":visible")){
    //alert("activa tabla user");
    $('#tzonas').DataTable( {
          "bLengthChange": false,
          "language": {
                    "lengthMenu": "Mostrar _MENU_",
                    "zeroRecords": "Nothing found - sorry",
                    "info": "Página _PAGE_ de _PAGES_ ",
                            //Registros _PAGE_ de Páginas",
                    "infoEmpty": "No records available",
                    "infoFiltered": "(Filtrados from _MAX_ total de registros)"
                }
           });
}



   
         
    $('select').formSelect();
    
    $('.collapsible').collapsible({
            menuWidth: 300,
            accordion : true
        });
        

               
$(window).load(function(){

 $(function() {
  $('#file-input').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida').attr("src",result);
     }
    });
    
  });
  
    function  getContextPath() {
           return window.location.pathname.substring(0,window.location.pathname.indexOf("/",2));
    }
     
    $(function(){
        $("#formuploadajax").on("submit", function(e){
            e.preventDefault();
            var f = $(this);
            var formData = new FormData(document.getElementById("formuploadajax"));
            formData.append("dato", "valor");
            $.ajax({
                url: getContextPath()+"/categoriasAdd",
                type: "post",
                dataType: "html",
                data: formData,
                cache: false,
                contentType: false,
	        processData: false,
                success: function(res){
                    if(res==="exito"){
                        if (confirm("La categoría se agregó correctamente. "
                                + "¿Desea seguir agregando categorías?")) {
                            $('#formuploadajax')[0].reset();
                            //location.href = "checkout.html";
                        }else{location.href = "checkout.html";}
                    }else{
                        alert("Lo sentimos, ocurrió un error.");
                        //$('#formuploadajax')[0].reset();
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
                    
            });
        });
    });
   
   
    $(function() {
        $("#formzona").on("submit", function(e){
            
            $.ajax({
                url: getContextPath()+"/zonaventaAdd",
                type: "post",
                dataType: "html",
                data: $("#formzona").serialize(),
                cache: false,
                success: function(res){
                    if(res==="exito"){
                        var confirmVal = window.confirm("La zona de venta se agregó correctamente. "
                                + "¿Desea seguir agregando categorías?");
                        if (confirmVal==true) {
                            $('#formzona')[0].reset();
                        }else{
                            location.href = "catalogo_zonaventa";
                        }
                    }else{
                        alert("Lo sentimos, ocurrió un error en la insercion.");
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
                    
            });
        });
        });
   
   
   $(function() {
        $("#formvendedor").on("submit", function(e){
        var zonav = $.trim($('#zona').val());
        var codigo = $.trim($('#codigo').val());
        var nomvendedor=$('#nomvendedor').val();
        var obs= $('#obs').val();
        var correo= $('#correo').val();
            $.ajax({
                url: getContextPath()+"/vendedoresAdd",
                type: "post",
                dataType: "html",
                data: {zona:zonav,codigo:codigo,nomvendedor:nomvendedor,correo:correo,obs:obs},
                cache: false,
                success: function(res){
                    if(res=="fail"){
                        alert(".");
                    }else{
                        alert("Se insertaron correctamente.");
                    }
                }
            });
    });
   });
   
     
   $(function() {
        $("#formusuarios").on("submit", function(e){
        var grupo = $.trim($('#grupo').val());
        var nc = $.trim($('#nombrecompleto').val());
        var usuario=$('#usuario').val();
        var pass= $('#pass').val();
        var correo= $('#correo').val();
            $.ajax({
                url: getContextPath()+"/usuariosAdd",
                type: "post",
                dataType: "html",
                data: {nc:nc,usuario:usuario,pass:pass,correo:correo,grupo:grupo},
                cache: false,
                success: function(data) {
                    return data; 
                 }
            });
    });
   });
   
   
   $(function(){
        $("#formpresentaciones").on("submit", function(e){
            e.preventDefault();
            var f = $(this);
            var estatus= $('#estatus').val();
            var formData = new FormData(document.getElementById("formpresentaciones"));
            formData.append("estatus", estatus);
            $.ajax({
                url: getContextPath()+"/presentacionesAdd",
                type: "post",
                dataType: "html",
                data: formData,
                cache: false,
                contentType: false,
	        processData: false,
                success: function(res){
                    if(res==="exito"){
                        if (window.confirm("La presentación se agregó correctamente. "
                                + "¿Desea seguir agregando?")) {
                                $('#formpresentaciones')[0].reset();
                        }else{location.href = "checkout.html";}
                    }else{
                        alert("Lo sentimos, ocurrió un error.");
                        //$('#formuploadajax')[0].reset();
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
                    
            });
        });
    });
    
    
    $('.pasar').click(function() { return !$('#origen option:selected').remove().appendTo('#destino'); });  
    $('.quitar').click(function() { return !$('#destino option:selected').remove().appendTo('#origen'); });
    $('.pasartodos').click(function() { $('#origen option').each(function() { $(this).remove().appendTo('#destino'); }); });
    $('.quitartodos').click(function() { $('#destino option').each(function() { $(this).remove().appendTo('#origen'); }); });
  
   $("#formasignacat").on("submit", function(e){
        var presentacion = $('#presentacion').val();
        $('#destino option').prop('selected', 'selected'); 
        var destino= $('#destino').val();
        alert(presentacion+"-"+destino+"-");
        $.ajax({
                url: getContextPath()+"/asignacategorias",
                type: "post",
                dataType: "html",
                data: {presentacion:presentacion,destino:destino},
                
                cache: false,
                success: function(res) {
                  if(res==="exito"){
                        if (window.confirm("La presentación se agregó correctamente. "
                                + "¿Desea seguir agregando?")) {
                              //  $('#formasignacat')[0].reset();
                        }else{
                            location.href = "checkout.html";}
                    }else{
                        alert("Lo sentimos, ocurrió un error.");
                        //$('#formuploadajax')[0].reset();
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
        });
    });

