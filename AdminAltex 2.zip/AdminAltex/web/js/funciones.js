/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function llenatabla(){
    $('#example').DataTable( {
          "bLengthChange": false,
          "language": {
                    "lengthMenu": "Mostrar _MENU_",
                    "zeroRecords": "Nothing found - sorry",
                    "info": "Página _PAGE_ de _PAGES_ ",
                            //Registros _PAGE_ de Páginas",
                    "infoEmpty": "No records available",
                    "infoFiltered": "(Filtrados from _MAX_ total de registros)"
                }
           });
       
}
$(document).ready(function(){ });
    

      
    $('select').formSelect();
      
    //$('select').material_select();
      
    $('.collapsible').collapsible({
            menuWidth: 300,
            accordion : true
        });
        

               
$(window).load(function(){

 $(function() {
  $('#file-input').change(function(e) {
      addImage(e); 
     });

     function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;
    
      if (!file.type.match(imageType))
       return;
  
      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
     }
  
     function fileOnload(e) {
      var result=e.target.result;
      $('#imgSalida').attr("src",result);
     }
    });
  });
  
    function  getContextPath() {
           return window.location.pathname.substring(0,window.location.pathname.indexOf("/",2));
    }
     
    $(function(){
        $("#formuploadajax").on("submit", function(e){
            e.preventDefault();
            var f = $(this);
            var formData = new FormData(document.getElementById("formuploadajax"));
            formData.append("dato", "valor");
            $.ajax({
                url: getContextPath()+"/categoriasAdd",
                type: "post",
                dataType: "html",
                data: formData,
                cache: false,
                contentType: false,
	        processData: false,
                success: function(res){
                    if(res==="exito"){
                        if (confirm("La categoría se agregó correctamente. "
                                + "¿Desea seguir agregando categorías?")) {
                            $('#formuploadajax')[0].reset();
                            //location.href = "checkout.html";
                        }else{location.href = "checkout.html";}
                    }else{
                        alert("Lo sentimos, ocurrió un error.");
                        //$('#formuploadajax')[0].reset();
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
                    
            });
        });
    });
   
   
    $(function() {
        $("#formzona").on("submit", function(e){
            
            $.ajax({
                url: getContextPath()+"/zonaventaAdd",
                type: "post",
                dataType: "html",
                data: $("#formzona").serialize(),
                cache: false,
                success: function(res){
                    if(res==="exito"){
                        var confirmVal = window.confirm("La zona de venta se agregó correctamente. "
                                + "¿Desea seguir agregando categorías?");
                        if (confirmVal==true) {
                            $('#formzona')[0].reset();
                        }else{
                            location.href = "catalogo_zonaventa";
                        }
                    }else{
                        alert("Lo sentimos, ocurrió un error en la insercion.");
                    }
                },
                error: function() {
                       alert("Lo sentimos, ocurrió un error.");
                }
                    
            });
        });
        });
   
   
   $(function() {
        $("#formvendedor").on("submit", function(e){
        var zonav = $.trim($('#zona').val());
        var codigo = $.trim($('#codigo').val());
        var nomvendedor=$('#nomvendedor').val();
        var obs= $('#obs').val();
        var correo= $('#correo').val();
            $.ajax({
                url: getContextPath()+"/vendedoresAdd",
                type: "post",
                dataType: "html",
                data: {zona:zonav,codigo:codigo,nomvendedor:nomvendedor,correo:correo,obs:obs},
                cache: false,
                success: function(res){
                    if(res=="fail"){
                        alert(".");
                    }else{
                        alert("Se insertaron correctamente.");
                    }
                }
            });
    });
   });
